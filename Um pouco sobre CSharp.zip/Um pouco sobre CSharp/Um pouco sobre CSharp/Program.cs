﻿using System;
using Um_pouco_sobre_CSharp.Utils;

namespace Um_pouco_sobre_CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            bool showMessagePressKey = true;
            WelcomeDialog welcomeDialog = new WelcomeDialog();

            while (showMessagePressKey)
            {
                welcomeDialog.SayHello();
                ExecuteMenuOption(ReadMenuOption(), out showMessagePressKey);

                Console.WriteLine();
                Console.WriteLine("Pressione qualquer tecla para continuar.");
                Console.ReadKey();
                Console.Clear();
            }
        }
        private static int ReadMenuOption()
        {
            Console.WriteLine("1 - Um pouco sobre Evento.");
            Console.WriteLine("2 - Um pouco sobre Delegado.");
            Console.WriteLine("3 - Um pouco sobre Fluxo de dados (Stream).");
            Console.WriteLine("4 - Um pouco sobre Arquivos.");
            Console.WriteLine("5 - Um pouco sobre Drives.");
            Console.WriteLine("6 - Um pouco sobre Informações de Arquivos.");
            Console.WriteLine("7 - Um pouco sobre Diretórios.");
            Console.WriteLine("8 - Um pouco sobre Lista de string.");
            Console.WriteLine("9 - Um pouco sobre Lista de objetos.");
            Console.WriteLine("10 - Um pouco sobre Set de string.");
            Console.WriteLine("11 - Um pouco sobre Set de objetos.");
            Console.WriteLine("12 - Um pouco sobre Métodos de Extensão.");
            Console.WriteLine("13 - Um pouco sobre Valores Nulos.");
            Console.WriteLine("14 - Um pouco sobre Referência de objetos.");
            Console.WriteLine("15 - Um pouco sobre Yield.");
            Console.WriteLine("16 - Um pouco sobre Iterators.");
            Console.WriteLine("Para sair, pressione qualquer tecla diferente das opções.");
            Int32.TryParse(Console.ReadLine(), out int keyRead);
            Console.Clear();
            return keyRead;
        }
        private static bool ExecuteMenuOption(int menuOption, out bool showMessagePressKey)
        {
            showMessagePressKey = true;

            switch (menuOption)
            {
                case 1:
                    {
                        ALittleAboutEvent aLittleOfEvents = new ALittleAboutEvent();
                        aLittleOfEvents.DoAction();
                        break;
                    };
                case 2:
                    {
                        ALittleAboutDelegate aLittleAboutDelegate = new ALittleAboutDelegate();
                        aLittleAboutDelegate.DoAction();
                        break;
                    };
                case 3:
                    {
                        ALittleAboutStream aLittleAboutStream = new ALittleAboutStream();
                        aLittleAboutStream.DoAction();
                        break;
                    };
                case 4:
                    {
                        ALittleAboutFile aLittleAboutFile = new ALittleAboutFile();
                        aLittleAboutFile.DoAction();
                        break;
                    }
                case 5:
                    {
                        ALittleAboutDrives aLittleAboutDrives = new ALittleAboutDrives();
                        aLittleAboutDrives.DoAction();
                        break;
                    }
                case 6:
                    {
                        ALittleAboutFileInformation aLittleAboutFileInformation = new ALittleAboutFileInformation();
                        aLittleAboutFileInformation.DoAction();
                        break;
                    }
                case 7:
                    {
                        ALittleAboutDirectory aLittleAboudDirectory = new ALittleAboutDirectory();
                        aLittleAboudDirectory.DoAction();
                        break;
                    }
                case 8:
                    {
                        ALittleAboutStringList aLittleAboutList = new ALittleAboutStringList();
                        aLittleAboutList.DoAction();
                        break;
                    }
                case 9:
                    {
                        ALittleAboutObjectList aLittleAboutObjectList = new ALittleAboutObjectList();
                        aLittleAboutObjectList.DoAction();
                    }
                    break;
                case 10:
                    {
                        ALittleAboutSet aLittleAboutSet = new ALittleAboutSet();
                        aLittleAboutSet.DoAction();
                    }
                    break;
                case 12:
                    {
                        ALittleAboutExtensionMethod aLittleAboutExtensionMethod = new ALittleAboutExtensionMethod();
                        aLittleAboutExtensionMethod.DoAction();
                    }
                    break;
                case 13:
                    {
                        ALittleAboutNullValue aLittleAboutNullValue = new ALittleAboutNullValue();
                        aLittleAboutNullValue.DoAction();
                    }
                    break;
                case 14:
                    {
                        ALittleAboutReferences aLittleAboutReferences = new ALittleAboutReferences();
                        aLittleAboutReferences.DoAction();
                    }
                    break;
                case 15:
                    {
                        ALittleAbourYield aLIttleAbourYield = new ALittleAbourYield();
                        aLIttleAbourYield.DoAction();
                    }
                    break;
                case 16:
                    {
                        ALittleAboutIterators aLittleAboutIterators = new ALittleAboutIterators();
                        aLittleAboutIterators.DoAction();
                    }
                    break;
                default:
                    {
                        showMessagePressKey = false;
                    }
                    break;
            }
            return showMessagePressKey;
        }
    }
}

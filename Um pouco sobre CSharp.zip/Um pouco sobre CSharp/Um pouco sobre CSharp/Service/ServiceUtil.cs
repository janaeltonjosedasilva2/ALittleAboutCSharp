﻿using System;
using System.Collections.Generic;
using System.Text;
using Um_pouco_sobre_CSharp.Abstracts;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;

namespace Um_pouco_sobre_CSharp.Service
{
    public class ServiceUtil
    {
        private IList<AbstractBaseUtil> _utils;

        public ServiceUtil(IServiceProvider provider)
        {
            _utils = provider.GetServices(typeof(AbstractBaseUtil))
                .Select(util => (AbstractBaseUtil)util)
                .OrderBy(util => util.UtilityName)
                .ToList();
        }

        public void Start()
        {
            int position = 0;
            
            Console.WriteLine("Bem vindo");
            IDictionary<int, AbstractBaseUtil> options = new Dictionary<int, AbstractBaseUtil>();

            foreach (AbstractBaseUtil util in _utils)
            {
                position++;
                Console.WriteLine(string.Format("{0} - {1}", position.ToString(), util.UtilityName));
                options.Add(position, util);
            }

            if(int.TryParse(Console.ReadLine(), out int option) && options.ContainsKey(option))
            {
                AbstractBaseUtil abstractBaseUtil = options[option];
                abstractBaseUtil.Start();
            }
            else
            {
                Console.WriteLine("Opção incorrata!");
                Console.ReadKey();
                Console.Clear();
                Start();
            }
        }
    }
}

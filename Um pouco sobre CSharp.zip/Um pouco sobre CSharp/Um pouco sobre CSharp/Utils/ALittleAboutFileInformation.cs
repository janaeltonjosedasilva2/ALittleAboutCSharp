﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    public class ALittleAboutFileInformation : AbstractCustomizationDialog, IALittleAbout
    {
        public void DoAction()
        {
            try
            {
                string fileName, textFile;
                GetParameters(out fileName, out textFile);
                
                File.WriteAllText(fileName, textFile);

                FileInfo fileInfo = new FileInfo(fileName);
                PrintFileDetail(fileInfo);
                ChangeAtributeFile(fileInfo);
                PrintArrayCharInConsole();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }

        private void ChangeAtributeFile(FileInfo fileInfo)
        {
            PrintMessageInConsole("Alterando atributo do arquivo criado");

            Console.WriteLine("Adicionando atributo Somente Leitura:");
            fileInfo.Attributes = fileInfo.Attributes | FileAttributes.ReadOnly;
            Console.WriteLine($"Nome do arquivo: {fileInfo.Attributes}");

            PrintArrayCharInConsole();

            Console.WriteLine("Removendo atributo Somente Leitura:");
            fileInfo.Attributes = fileInfo.Attributes & ~FileAttributes.ReadOnly;
            Console.WriteLine($"Nome do arquivo: {fileInfo.Attributes}");
        }

        private void PrintFileDetail(FileInfo fileInfo)
        {
            PrintMessageInConsole("Exibindo mais informações do arquivo criado");

            Console.WriteLine($"Nome do arquivo: {fileInfo.Name}");
            Console.WriteLine($"Diretório: {fileInfo.FullName}");
            Console.WriteLine($"Último acesso: {fileInfo.LastAccessTime}");
            Console.WriteLine($"Tamanho em bytes: {fileInfo.Length}");
            Console.WriteLine($"Atributos: {fileInfo.Attributes}");
        }

        private void GetParameters(out string fileName, out string textFile)
        {
            Console.WriteLine("Informe o nome para o arquivo texto sem a extensão:");
            fileName = $"{Console.ReadLine()}.txt";

            Console.WriteLine("Informe o texto para o arquivo:");
            textFile = $"{Console.ReadLine()}\n";
        }
    }
}

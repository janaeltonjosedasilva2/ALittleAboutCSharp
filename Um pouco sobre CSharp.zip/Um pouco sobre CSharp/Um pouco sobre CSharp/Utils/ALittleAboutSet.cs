﻿using System;
using System.Collections.Generic;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutSet : AbstractCustomizationDialog, IALittleAbout
    {
        public void DoAction()
        {
            PrintMessageInConsole("Um pouco sobre data set");
            Console.WriteLine("Você sabia que o HashSet possui uma busca mais rápida que um List?");
            Console.ReadKey();

            ISet<string> myStringSet = new HashSet<string>();
            myStringSet.Add("Qualquer coisa");
            myStringSet.Add("Outra qualquer coisa");
            myStringSet.Add("Mais outra qualquer coisa");
            PrintDataSet(myStringSet);

            PrintArrayCharInConsole();
            Console.WriteLine("Mas qual a diferença entre List e um Set?");
            Console.ReadKey();

            PrintArrayCharInConsole();
            Console.WriteLine("Primeiro ponto é a ordenação que não é mesma da lista.");
            myStringSet.Remove("Outra qualquer coisa");
            myStringSet.Add("Qualquer outra coisa");

            PrintDataSet(myStringSet);

            PrintArrayCharInConsole();
            Console.WriteLine("Você não consegue ordernar os itens, pois o Set usar uma tabela de espelhamento para fazer a busca.");

            List<string> clone = new List<string>(myStringSet);

            PrintArrayCharInConsole();
            clone.Sort();
            Console.WriteLine("Para isso precisamos criar uma lista e fazer o Sort.");
            Console.WriteLine(string.Join(", ", clone));
            Console.ReadKey();

            PrintArrayCharInConsole();
            Console.WriteLine("Num Set também não há valores repetidos.");
            myStringSet.Add("Qualquer outra coisa");
            PrintDataSet(myStringSet);
        }

        private static void PrintDataSet(ISet<string> myStringSet)
        {
            Console.WriteLine($"Itens do Set: {string.Join(", ", myStringSet)}");
        }
    }
}

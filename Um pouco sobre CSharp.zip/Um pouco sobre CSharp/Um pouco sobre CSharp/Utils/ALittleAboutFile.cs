﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutFile : AbstractCustomizationDialog, IALittleAbout
    {
        public void DoAction()
        {
            try
            {
                string fileName, textFile, fileNameToCopy;
                GetParameters(out fileName, out textFile);
                PrintArrayCharInConsole();

                CreateFile(fileName, textFile);
                PrintArrayCharInConsole();

                AppendTextInFile(fileName);
                PrintArrayCharInConsole();

                CopyFile(fileName, out fileNameToCopy);
                PrintArrayCharInConsole();

                ReadTextFromFileCopy(fileName, fileNameToCopy);
                PrintArrayCharInConsole();
                ReadTextFromFileCopyUsingStream(fileNameToCopy);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }

        }

        private static void ReadTextFromFileCopyUsingStream(string fileNameToCopy)
        {
            Console.WriteLine("Agora usando fluxo de dados para ler o arquivo:");
            using (StreamReader streamFile = File.OpenText(fileNameToCopy))
            {
                string textFromCopyFile = streamFile.ReadToEnd();
                Console.WriteLine($"Isso foi o que você digitou:\n{textFromCopyFile}");
            }
        }

        private static void ReadTextFromFileCopy(string fileName, string fileNameToCopy)
        {
            Console.WriteLine($"Lendo o arquivo {fileNameToCopy}");
            string textFromCopyFile = File.ReadAllText(fileName, Encoding.UTF8);
            Console.WriteLine($"Isso foi o que você digitou:\n{textFromCopyFile}");
        }

        private void CopyFile(string fileNameText, out string fileNameToCopy)
        {
            Console.WriteLine("Vamos copiar o arquivo texto, para isso digito o nome para a cópia:");
            fileNameToCopy = $"{Console.ReadLine()}.txt";
            File.Copy(fileNameText, fileNameToCopy, true);
        }

        private static void AppendTextInFile(string fileName)
        {
            Console.WriteLine("Digite mais alguma coisa para inserir no arquivo texto.");
            string textToAppend = Console.ReadLine();

            File.AppendAllText(fileName, textToAppend);
        }

        private static void CreateFile(string fileName, string textFile)
        {
            Console.WriteLine("Criando arquivo texto usando o método estático da classe File.");
            File.WriteAllText(fileName, textFile);
        }

        private void GetParameters(out string fileName, out string textFile)
        {
            Console.WriteLine("Informe o nome para o arquivo texto sem a extensão:");
            fileName = $"{Console.ReadLine()}.txt";

            Console.WriteLine("Informe o texto para o arquivo:");
            textFile = $"{Console.ReadLine()}\n";
        }
    }
}

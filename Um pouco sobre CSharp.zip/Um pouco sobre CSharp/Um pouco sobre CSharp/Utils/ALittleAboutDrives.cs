﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutDrives : AbstractCustomizationDialog, IALittleAbout
    {
        private const int KILOBYTE = 1024;
        public void DoAction()
        {
            var driveInfo = DriveInfo.GetDrives();

            PrintMessageInConsole("Drives do sistema");

            foreach (var drive in driveInfo)
            {
                Console.WriteLine("Nome do drive:");
                Console.WriteLine("{0}", drive.Name);
                PrintArrayCharInConsole();

                if (!drive.IsReady)
                {
                    Console.WriteLine("Drive não está disponível");
                    PrintArrayCharInConsole();
                    continue;
                }

                Console.WriteLine("Tipo do drive:");
                Console.WriteLine("{0}", drive.DriveType);
                PrintArrayCharInConsole();

                Console.WriteLine("Formato do drive:");
                Console.WriteLine("{0}", drive.DriveFormat);
                PrintArrayCharInConsole();

                Console.WriteLine("Espaço livre em");

                double bytes = drive.TotalFreeSpace;
                Console.WriteLine("KB: {0:N2}", bytes);

                double kb = bytes / KILOBYTE;
                Console.WriteLine("KB: {0:N2}", kb);

                double mb = kb / KILOBYTE;
                Console.WriteLine("KB: {0:N2}", mb);

                double gb = mb / KILOBYTE;
                Console.WriteLine("KB: {0:N2}", gb);

                double tb = gb / KILOBYTE;
                Console.WriteLine("KB: {0:N2}", tb);
                PrintArrayCharInConsole();
            }

        }
    }
}

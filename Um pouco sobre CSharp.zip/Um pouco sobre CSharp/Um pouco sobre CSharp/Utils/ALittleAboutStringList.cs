﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutStringList : AbstractCustomizationDialog, IALittleAbout
    {
        public void DoAction()
        {
            bool showMessagePressKey = true;

            List<string> listWords = new List<string>();

            while (showMessagePressKey)
            {
                PrintMessageInConsole("Manipulando listas de texto");
                ExecuteMenuOption(listWords, ReadMenuOption(), out showMessagePressKey);
                Console.Clear();
            }

        }
        private static int ReadMenuOption()
        {
            Console.WriteLine("O que deseja fazer:");
            Console.WriteLine("1 - Adicionar palavra ou texto na lista.");
            Console.WriteLine("2 - Listar as palavras inseridas na lista.");
            Console.WriteLine("3 - Texto a partir de uma palavra ou texto.");
            Console.WriteLine("4 - Ordernar a lista de palavras.");
            Console.WriteLine("5 - Remover um item da lista.");
            Console.WriteLine("6 - Copiar para outra lista uma faixa de itens da lista atual.");
            Console.WriteLine("7 - Copiar a lista de palavras para outra lista.");
            Console.WriteLine("0 - Para sair.");
            Int32.TryParse(Console.ReadLine(), out int keyRead);
            return keyRead;
        }

        private static bool ExecuteMenuOption(List<string> listWords, int keyRead, out bool showMessagePressKey)
        {
            showMessagePressKey = true;

            switch (keyRead)
            {
                case 1:
                    AddWordIntoList(listWords);
                    break;
                case 2:
                    InterateList(listWords);
                    break;
                case 3:
                    GetFistItemFromList(listWords);
                    break;
                case 4:
                    SortList(listWords);
                    break;
                case 5:
                    {
                        if (!IsEmptyList(listWords))
                            RemoveItemByIndex(listWords);
                    };
                    break;
                case 6:
                    {
                        if (!IsEmptyList(listWords))
                            CopyRangeItensFromList(listWords);
                    };
                    break;
                case 7:
                    {
                        if (!IsEmptyList(listWords))
                            CopyList(listWords);
                    };
                    break;
                case 0:
                default:
                    showMessagePressKey = false;
                    break;
            }

            return showMessagePressKey;
        }

        private static void CopyList(List<string> listWords)
        {
            PrintArrayCharInConsole();
            List<string> copyListWords = new List<string>(listWords);

            Console.WriteLine("Lista copiada:");
            InterateList(copyListWords);
        }

        private static void CopyRangeItensFromList(List<string> listWords)
        {

            PrintArrayCharInConsole();
            Console.WriteLine("Digite o item que deseja copiar a partir.");

            InterateListItensWithIndex(listWords);

            Int32.TryParse(Console.ReadLine(), out int keyPressRead);

            if (keyPressRead > listWords.Count() || keyPressRead < 0)
            {
                Console.WriteLine("Número digitado não corresponde com algumas das opções informadas.");
                Console.ReadKey();
            }
            else
            {
                List<string> listWordsToCopyRange = listWords.GetRange(keyPressRead, listWords.Count - keyPressRead);

                PrintArrayCharInConsole();
                Console.WriteLine("Itens copiados:");
                InterateListItensWithIndex(listWordsToCopyRange);
                Console.ReadKey();
            }
        }

        private static bool IsEmptyList(List<string> listWords)
        {
            if (listWords.Count() == 0)
            {
                PrintArrayCharInConsole();
                Console.WriteLine("Não há itens na lista!");
                Console.ReadKey();
                return true;
            }
            return false;
        }

        private static void RemoveItemByIndex(List<string> listWords)
        {
            PrintArrayCharInConsole();
            Console.WriteLine("Digite o número do item que deseja excluir.");

            InterateListItensWithIndex(listWords);

            Int32.TryParse(Console.ReadLine(), out int keyPressRead);

            if (keyPressRead > listWords.Count() || keyPressRead < 0)
            {
                Console.WriteLine("Número digitado não corresponde com algumas das opções informadas.");
                Console.ReadKey();
            }
            else
                listWords.RemoveAt(keyPressRead);
        }

        private static void InterateListItensWithIndex(List<string> listWords)
        {
            int indexList = 0;
            listWords.ForEach(word =>
            {
                Console.WriteLine($"{indexList} - {word}");
                indexList++;
            });
        }

        private static void SortList(List<string> listWords)
        {
            PrintArrayCharInConsole();
            listWords.Sort();
            listWords.ForEach(word => Console.WriteLine(word));
            Console.ReadKey();
        }

        private static void GetFistItemFromList(List<string> listWords)
        {
            PrintArrayCharInConsole();
            Console.WriteLine("Digite uma palavra para encontrar o primeiro registro ela na lista.");
            string wordToFind = Console.ReadLine();

            string index = listWords.FirstOrDefault(word => word.Contains(wordToFind));

            if (String.IsNullOrEmpty(index))
                Console.WriteLine($"O texto {wordToFind} não foi encontrado!");
            else
                Console.WriteLine("Texto encontrado: " + index);

            Console.ReadKey();
        }

        private static void InterateList(List<string> listWords)
        {
            PrintArrayCharInConsole();
            listWords.ForEach(word => Console.WriteLine(word));
            Console.ReadKey();
        }

        private static void AddWordIntoList(List<string> listaDePalavras)
        {
            PrintArrayCharInConsole();
            Console.WriteLine("Digite alguma coisa para adicionar na lista de palavras.");
            listaDePalavras.Add(Console.ReadLine());
        }
    }
}

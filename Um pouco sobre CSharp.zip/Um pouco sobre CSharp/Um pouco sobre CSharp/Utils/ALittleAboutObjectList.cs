﻿using System;
using System.Collections.Generic;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;
using Um_pouco_sobre_CSharp.Model;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutObjectList : AbstractCustomizationDialog, IALittleAbout
    {
        public void DoAction()
        {
            bool showMessagePressKey = true;

            List<Discipline> disciplines = new List<Discipline>();

            while (showMessagePressKey)
            {
                PrintMessageInConsole("Manipulando listas de objetos");
                ExecuteMenuOption(disciplines, ReadMenuOption(), out showMessagePressKey);
                Console.Clear();
            }

        }
        private static int ReadMenuOption()
        {
            Console.WriteLine("O que deseja fazer:");
            Console.WriteLine("1 - Adicionar disciplina.");
            Console.WriteLine("2 - Ordenar as disciplinas pelo nome.");
            Console.WriteLine("3 - Ordenar as disciplinas pela hora.");
            Console.WriteLine("0 - Para sair.");
            Int32.TryParse(Console.ReadLine(), out int keyRead);
            return keyRead;
        }

        private static bool ExecuteMenuOption(List<Discipline> disciplines, int keyRead, out bool showMessagePressKey)
        {
            showMessagePressKey = true;

            switch (keyRead)
            {
                case 1:
                    AddDisciplineInCourse(disciplines);
                    break;
                case 2:
                    SortList(disciplines);
                    break;
                case 3:
                    SortListByTime(disciplines);
                    break;
                case 0:
                default:
                    showMessagePressKey = false;
                    break;
            }

            return showMessagePressKey;
        }

        private static void SortListByTime(List<Discipline> disciplines)
        {
            PrintArrayCharInConsole();

            disciplines.Sort((thisDiscipline, thatDiscipline) => thisDiscipline.Time.CompareTo(thatDiscipline.Time));
            IterateListItens(disciplines);
        }

        private static void IterateListItens(List<Discipline> disciplines)
        {
            disciplines.ForEach(disciplina => Console.WriteLine(disciplina));
            Console.ReadKey();
        }

        private static void SortList(List<Discipline> disciplines)
        {
            PrintArrayCharInConsole();

            disciplines.Sort();
            IterateListItens(disciplines);
        }

        private static void AddDisciplineInCourse(List<Discipline> disciplines)
        {
            PrintArrayCharInConsole();

            GetInputText("Digite um nome para a disciplina.", out string disciplineName);
            GetInputText("Digite um nome para o Instrutor.", out string instructorName);
            GetInputText("Digite a quantidade de horas da aula.", out string horasInText);

            if (String.IsNullOrEmpty(disciplineName))
                disciplineName = "Disciplina sem nome";
            if (String.IsNullOrEmpty(instructorName))
                instructorName = "Instrutor sem nome";

            Int32.TryParse(horasInText, out int horas);

            disciplines.Add(new Discipline(disciplineName, horas, instructorName));
        }

        private static void GetInputText(string textToShow, out string textRead)
        {
            Console.WriteLine(textToShow);
            textRead = Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;
using Um_pouco_sobre_CSharp.Model;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutExtensionMethod : AbstractCustomizationDialog, IALittleAbout
    {
        public void DoAction()
        {
            PrintMessageInConsole("Como usar um método de extensão");
            Console.WriteLine("Digite uma lista de palavras ou números separados por vírgula.");
            string[] listItens = Console.ReadLine().Split(',');

            List<string> listCopy = new List<string>();

            listCopy.AddRangeValues(listItens);
            PrintItensList(listCopy);
        }

        private static void PrintItensList(List<string> listCopy)
        {
            PrintArrayCharInConsole();
            Console.WriteLine("Itens copiados:");
            listCopy.ForEach(item => Console.WriteLine(item));
            Console.ReadKey();
        }
    }
}

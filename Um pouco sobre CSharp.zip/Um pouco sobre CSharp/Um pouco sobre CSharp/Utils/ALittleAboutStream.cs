﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutStream : AbstractCustomizationDialog, IALittleAbout
    {
        public void DoAction()
        {
            try
            {
                string fileName, textFile;
                GetParameters(out fileName, out textFile);

                string fileNameText = $"{fileName}.txt", fileNameZip = $"{fileName}.zip";
                PrintArrayCharInConsole();

                CreateTextFile(fileNameText, textFile);
                PrintArrayCharInConsole();

                byte[] bytesFromTextFile = File.ReadAllBytes(fileNameText);

                CompressFile(fileNameText, fileNameZip, bytesFromTextFile);
                PrintArrayCharInConsole();
                DecompressFile(fileNameZip);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }

        private void DecompressFile(string fileNameZip)
        {
            Console.WriteLine("Descompactando o arquivo texto:");
            using (FileStream fileNameCompress = new FileStream($"{fileNameZip}", FileMode.Open, FileAccess.Read))
            using (GZipStream decompress = new GZipStream(fileNameCompress, CompressionMode.Decompress))
            using (StreamReader textFile = new StreamReader(decompress))
            {
                string textFromFile = textFile.ReadToEnd();
                Console.WriteLine($"O conteúdo do arquivo é: {textFromFile}");
            }
        }

        private void CompressFile(string fileNameText, string fileNameZip, byte[] bytesFromTextFile)
        {
            Console.WriteLine("Compactando o arquivo texto criado:");
            using (FileStream fileNameCompress = new FileStream(fileNameZip, FileMode.OpenOrCreate, FileAccess.Write))
            using (GZipStream compress = new GZipStream(fileNameCompress, CompressionMode.Compress))
            {
                compress.Write(bytesFromTextFile, 0, bytesFromTextFile.Length);
                Console.WriteLine($"Comprimindo o arquivo {fileNameText}");
            }
        }

        private void CreateTextFile(string fileNameText, string textToFile)
        {
            using (StreamWriter file = new StreamWriter(fileNameText))
            {
                file.Write(textToFile);
            }

            Console.WriteLine("Agora lendo o que você escreveu:");

            using (StreamReader file = new StreamReader(fileNameText))
            {
                string textRead = file.ReadToEnd();
                Console.WriteLine(textToFile);
            }
        }

        private void GetParameters(out string fileName, out string textFile)
        {
            Console.WriteLine("Informe o nome para o arquivo texto sem a extensão:");
            fileName = Console.ReadLine();

            Console.WriteLine("Informe o texto para o arquivo:");
            textFile = Console.ReadLine();
        }
    }
}

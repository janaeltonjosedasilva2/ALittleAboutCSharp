﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutDirectory : AbstractCustomizationDialog, IALittleAbout
    {
        public void DoAction()
        {
            try
            {
                string directoryName = GetParamiters();
                PrintArrayCharInConsole();
                CreateDirectory(directoryName);
                PrintArrayCharInConsole();
                DeleteDirectory(directoryName);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }

        private void DeleteDirectory(string directoryName)
        {
            if (!Directory.Exists(directoryName))
            {
                Console.WriteLine($"Diretório {directoryName} não existe!");
                return;
            }

            Directory.Delete(directoryName);
            Console.WriteLine("Diretório deletado!");
        }
        private void CreateDirectory(string directoryName)
        {
            Console.WriteLine("Criado diretório:");
            if (Directory.Exists(directoryName))
            {
                Console.WriteLine($"Diretório {directoryName} já existe!");
                return;
            }

            Directory.CreateDirectory(directoryName);
            Console.WriteLine("Diretório criado!");
        }
        private string GetParamiters()
        {
            Console.WriteLine("Digite um nome para o novo diretório:");
            string directoryName = Console.ReadLine();
            return directoryName;
        }
    }
}

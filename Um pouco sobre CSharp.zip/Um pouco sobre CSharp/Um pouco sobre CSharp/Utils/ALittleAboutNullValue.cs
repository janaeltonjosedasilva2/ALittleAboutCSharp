﻿using System;
using System.Collections.Generic;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutNullValue : AbstractCustomizationDialog, IALittleAbout
    {
        private const int _variableIntOfExemples = 5;
        private const string _variableStringOfExemples = "AbcDef";

        public void DoAction()
        {
            FistExemple();
            SecondExemple();
        }

        private void SecondExemple()
        {
            PrintMessageInConsole("Segundo exemplo ao lidar com nulo:");
            Console.WriteLine(Truncate(null, _variableIntOfExemples));

            Console.WriteLine(Truncate(_variableStringOfExemples, _variableIntOfExemples));
        }

        private string Truncate(string work, int length)
        {
            return work?.Substring(0, Math.Min(work.Length, length));
        }

        private static void FistExemple()
        {
            PrintMessageInConsole("Primeiro exemplo ao lidar com nulo:");
            IList<int> numberList = null;
            int? thing = null;

            (numberList ??= new List<int>()).Add(_variableIntOfExemples);
            Console.WriteLine(string.Join(" ", numberList));

            numberList.Add(thing ??= 0);
            Console.WriteLine(string.Join(" ", numberList));
            Console.WriteLine(thing);
        }
    }
}

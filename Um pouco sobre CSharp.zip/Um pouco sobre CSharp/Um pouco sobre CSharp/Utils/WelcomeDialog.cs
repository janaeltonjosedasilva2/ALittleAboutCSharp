﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Um_pouco_sobre_CSharp.Utils
{

    class WelcomeDialog : AbstractCustomizationDialog
    {
        protected const string welcomeMessage = "Bem vindo - Welcome - Bienvenido - Bienvenue";
        public void SayHello()
        {
            if (countCharForPrintConsole < welcomeMessage.Length + 1)
            {
                Console.WriteLine(welcomeMessage);
                PrintArrayCharInConsole();
                return;
            }

            PrintMessageInConsole(welcomeMessage);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutDelegate : AbstractCustomizationDialog, IALittleAbout
    {
        delegate int Operation(int a, int b);
        public void DoAction()
        {
            try
            {
                int a, b;
                GetParameters(out a, out b);
                PrintArrayCharInConsole();
                CallADelegate(a, b);
                PrintArrayCharInConsole();
                CallADelegateFunc(a, b);
                PrintArrayCharInConsole();
                CallADelegateAction();
                PrintArrayCharInConsole();
                CallADelegatePredicate();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }

        private void CallADelegatePredicate()
        {
            Console.WriteLine("Agora um delegado legal. Olho como funcina o predicado que sempre retorna falso ou verdadeiro:");
            Console.WriteLine();

            Predicate<int> delegadoPredicate = (number) => number % 3 == 0;
            Console.WriteLine("Digite uma lista de números inteiros separados por virgula (,) para saber se são divisíveis por 3.");
            string[] numberList = Console.ReadLine().Split(",");
            foreach (var numberString in numberList)
            {
                Int32.TryParse(numberString, out int number);
                if (delegadoPredicate(number))
                {
                    Console.WriteLine($"{number} é divisível por 3");
                }

            }
        }

        private void CallADelegateAction()
        {
            Console.WriteLine("Um delegado de ação (não retorna valor):");
            Action<string> delegateAction = (message) => { Console.WriteLine(message); };
            delegateAction("Olha o monstro vindo!");
        }

        private void CallADelegateFunc(int a, int b)
        {
            Console.WriteLine("Um delegado de função (retorna um valor):");
            Func<int, int, int> delegateFunc = (x, y) => x + y;
            Console.WriteLine(delegateFunc(a, b));
        }

        private void CallADelegate(int a, int b)
        {
            Operation operation = new Operation(Sum);
            Console.WriteLine(operation(a, b));

            operation = new Operation(Multiply);
            Console.WriteLine(operation(a, b));

            Console.WriteLine("Atribuindo um método anônimo ao delegado:");
            operation = (x, y) => { return x + y; };
            Console.WriteLine(operation(a, b));

            Console.WriteLine("Num formato mais simplificado ainda:");
            operation = (x, y) => x - y;
            Console.WriteLine(operation(a, b));
        }

        private void GetParameters(out int a, out int b)
        {
            Console.WriteLine("Digite um valor para a vatiável 'A':");
            Int32.TryParse(Console.ReadLine(), out a);

            Console.WriteLine("Digite um valor para a vatiável 'B':");
            Int32.TryParse(Console.ReadLine(), out b);
        }

        private int Sum(int a, int b)
        {
            Console.WriteLine($"Operação Somar foi chamado para {a} + {b}");
            return a + b;
        }
        private int Multiply(int a, int b)
        {
            Console.WriteLine($"Operação Multiplicar foi chamado para {a} * {b}");
            return a * b;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutIterators : AbstractCustomizationDialog, IALittleAbout
    {
        public void DoAction()
        {
            PrintMessageInConsole("Um pouco sobre iteradores");

            PrintItens(GetSingleDigitNumbers());
            PrintItens(GetSingleDigitNumbersLoop());
            PrintItens(GetSetsOfNumbers());
            PrintItens(Example.Sample(GetSingleDigitNumbers(), 2));
            PrintItens(GetFirstDecile());
            PrintItens(GetSingleDigitOddNumbers(true));

            Console.ReadKey();
        }

        private static void PrintItens(IEnumerable<int> itens)
        {
            foreach (var item in itens)
            {
                Console.WriteLine(item);
            }
            PrintArrayCharInConsole();
        }

        public IEnumerable<int> GetSingleDigitNumbers()
        {
            yield return 0;
            yield return 1;
            yield return 2;
            yield return 3;
            yield return 4;
            yield return 5;
            yield return 6;
            yield return 7;
            yield return 8;
            yield return 9;
        }

        public IEnumerable<int> GetSingleDigitNumbersLoop()
        {
            int index = 0;
            while (index < 10)
                yield return index++;
        }

        public IEnumerable<int> GetSetsOfNumbers()
        {
            int index = 0;
            while (index < 10)
                yield return index++;

            yield return 50;

            index = 100;
            while (index < 110)
                yield return index++;
        }

        public IEnumerable<int> GetFirstDecile()
        {
            int index = 0;
            while (index < 10)
                yield return index++;

            yield return 50;

            var items = new int[] { 100, 101, 102, 103, 104, 105, 106, 107, 108, 109 };
            foreach (var item in items)
                yield return item;
        }

        public IEnumerable<int> GetSingleDigitOddNumbers(bool getCollection)
        {
            if (getCollection == false)
                return new int[0];
            else
                return IteratorMethod();
        }

        private IEnumerable<int> IteratorMethod()
        {
            int index = 0;
            while (index < 10)
            {
                if (index % 2 == 1)
                    yield return index;
                index++;
            }
        }
    }

    public static class Example
    {
        public static IEnumerable<T> Sample<T>(this IEnumerable<T> sourceSequence, int interval)
        {
            int index = 0;
            foreach (T item in sourceSequence)
            {
                if (index++ % interval == 0)
                    yield return item;
            }
        }
    }
}

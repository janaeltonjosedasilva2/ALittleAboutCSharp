﻿using System;
using System.Collections.Generic;
using Um_pouco_sobre_CSharp.Interfaces;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutEvent: AbstractCustomizationDialog, IALittleAbout
    {
        public void DoAction()
        {
            try
            {
                Bell bell = new Bell();
                bell.OnBellRang += BellRang;

                Console.WriteLine("Digite o número do apartamento que deseja tocar a campainha.");
                string apartment = Console.ReadLine();
                bell.Ring(apartment);
                PrintArrayCharInConsole();

                Console.WriteLine($"Digite 's' para tocar a campainha do apartamento {apartment} novamente.");
                string ringAgain = Console.ReadLine();
                if (ringAgain.ToLower() == "s")
                {
                    bell.OnBellRang -= BellRang;
                    bell.OnBellRang += BellRangAgain;
                    bell.Ring(apartment);
                }
                PrintArrayCharInConsole();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }
        private void BellRang(object sender, BellEventArgs args)
        {
            Console.WriteLine($"A campainha do apartamento {args.Apartment} tocou!");
        }
        private void BellRangAgain(object sender, BellEventArgs args)
        {
            Console.WriteLine($"A campainha do apartamento {args.Apartment} tocou novamente!");
        }
    }
    class Bell
    {
        public event EventHandler<BellEventArgs> OnBellRang;

        public void Ring(string apartment)
        {
            List<Exception> exceptions = new List<Exception>();

            foreach (var manipulator in OnBellRang.GetInvocationList())
            {
                try
                {
                    manipulator.DynamicInvoke(this, new BellEventArgs(apartment));
                }
                catch (Exception e)
                {
                    exceptions.Add(e.InnerException);
                }
            }
        }

    }
    class BellEventArgs : EventArgs
    {
        public BellEventArgs(string apartment)
        {
            Apartment = apartment;
        }
        public string Apartment { get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Um_pouco_sobre_CSharp.Interfaces;
using Um_pouco_sobre_CSharp.Model;

namespace Um_pouco_sobre_CSharp.Utils
{
    class ALittleAboutReferences : AbstractCustomizationDialog, IALittleAbout
    {
        Random enrollment = new Random();
        public void DoAction()
        {
            PrintMessageInConsole("Um pouco sobre referência de objetos");
            Student student = new Student("Nome do estudante", enrollment.Next());

            PrintStudent(student);
            ChangeNameByReferenceObject(ref student);
            ChangeNameSimpleMode(student);
            ChangeEnrollmentByReferenceObject(ref student);
            ChangeEnrollmentSimpleMode(student);
            PrintStudent(student);
            Console.ReadKey();
        }

        private void ChangeEnrollmentSimpleMode(Student student)
        {
            student.Enrollment = enrollment.Next();
            PrintStudent(student);
        }

        private void PrintStudent(Student student)
        {
            Console.WriteLine($"Nome: {student.Name}, Matrícula: {student.Enrollment}");
            PrintArrayCharInConsole();
        }

        private void ChangeEnrollmentByReferenceObject(ref Student student)
        {
            student.Enrollment = enrollment.Next();
            PrintStudent(student);
        }
        private void ChangeNameSimpleMode(Student student)

        {
            student.Name = "Nome alterado - Modo comum";
            PrintStudent(student);
        }

        private void ChangeNameByReferenceObject(ref Student student)
        {
            student.Name = "Nome alterado - Referência";
            PrintStudent(student);
        }
    }
}

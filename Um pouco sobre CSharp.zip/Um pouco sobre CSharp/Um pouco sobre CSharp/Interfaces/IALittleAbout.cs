﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Um_pouco_sobre_CSharp.Interfaces
{
    interface IALittleAbout
    {
        public void DoAction();
    }
}

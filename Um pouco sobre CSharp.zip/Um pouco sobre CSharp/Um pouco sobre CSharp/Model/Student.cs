﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Um_pouco_sobre_CSharp.Model
{
    class Student
    {
        private string name;
        private int enrollment;

        public Student(string name, int enrollment)
        {
            this.name = name;
            this.enrollment = enrollment;
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Enrollment
        {
            get { return enrollment; }
            set { enrollment = value; }
        }

        public override bool Equals(object obj)
        {
            Student student = obj as Student;

            if (student == null)
            {
                return false;
            }

            return this.name.Equals(student.name);
        }

        public override int GetHashCode()
        {
            return this.name.GetHashCode();
        }
    }
}

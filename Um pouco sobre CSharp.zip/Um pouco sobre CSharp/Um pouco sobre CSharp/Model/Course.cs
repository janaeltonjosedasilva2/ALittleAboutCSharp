﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Um_pouco_sobre_CSharp.Model;

namespace Um_pouco_sobre_CSharp.Model
{
    class Course
    {
        private IDictionary<int, Student> dictionaryStudent = new Dictionary<int, Student>();
        private IList<Discipline> disciplines;
        private string name;
        private ISet<Student> students = new HashSet<Student>();
        public Course(string name)
        {
            this.name = name;
            this.disciplines = new List<Discipline>();
        }

        public IList<Discipline> Disciplines
        {
            get { return new ReadOnlyCollection<Discipline>(disciplines); }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        internal void AddDiscipline (Discipline discipline)
        {
            disciplines.Add(discipline);
        }

        public int AllTime
        {
            get
            {
                return disciplines.Sum(discipline => discipline.Time);
            }
        }

        public override string ToString()
        {
            return $"Curso: {name}, Tempo: {AllTime}, Disciplines: {string.Join(",", disciplines)}";
        }

        public void Enroll (Student student)
        {
            students.Add(student);
            dictionaryStudent.Add(student.Enrollment, student);
        }

        public Student GetStudentByEnrollment(int enrollment)
        {
            dictionaryStudent.TryGetValue(enrollment, out Student student);
            return student;
        }

        public void ReplaceStudent(Student student)
        {
            dictionaryStudent[student.Enrollment] = student;
        }

        //Para retornar a propriedade Student de forma segura, impedindo o acesso de escrita direto pela classe Course, 
        //precisamos converter o Set num List e usar ReadOnlyCollection.
        public IList<Student> Student
        {
            get
            {
                return new ReadOnlyCollection<Student>(students.ToList());
            }
        }
    }
}

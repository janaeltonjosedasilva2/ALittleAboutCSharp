﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Um_pouco_sobre_CSharp.Model
{
    class Discipline : IComparable
    {
        private string name;
        private int time;
        private string instructor;

        public Discipline(string name, int time, string instructor)
        {
            this.name = name;
            this.time = time;
            this.Instructor = instructor;
        }

        public string Name { get => name; set => name = value; }
        public int Time { get => time; set => time = value; }
        public string Instructor { get => instructor; set => instructor = value; }

        public int CompareTo(object obj)
        {
            Discipline discipline = obj as Discipline;
            return name.CompareTo(discipline.name);
        }

        public override string ToString()
        {
            return $"Disciplina: {name}, instrutor: {instructor}, tempo: {time} horas.";
        }
    }
}

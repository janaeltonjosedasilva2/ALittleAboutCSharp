﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Um_pouco_sobre_CSharp.Model
{
    public static class ListExtensions
    {
        public static void AddRangeValues<T>(this List<T> list, params T[] itens)
        {
            foreach (T item in itens)
            {
                list.Add(item);
            }
        }
    }
}

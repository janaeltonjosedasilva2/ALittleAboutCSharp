﻿using System;

namespace Um_pouco_sobre_CSharp.Utils
{
    public abstract class AbstractCustomizationDialog
    {
        protected const int countCharForPrintConsole = 60;
        private const char charToPrint = '=';

        protected static void PrintArrayCharInConsole()
        {
            Console.WriteLine(new string(charToPrint, countCharForPrintConsole));
        }

        protected static void PrintMessageInConsole(string message)
        {
            PrintArrayCharInConsole();
            Console.WriteLine(new string(charToPrint, (countCharForPrintConsole - message.Length) / 2) + message + new string(charToPrint, (countCharForPrintConsole - message.Length) / 2));
            PrintArrayCharInConsole();
        }
    }
}
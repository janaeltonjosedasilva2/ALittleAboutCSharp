﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Um_pouco_sobre_CSharp.Abstracts
{
    public abstract class AbstractBaseUtil
    {
        public abstract string UtilityName { get; }
        
        public override string ToString()
        {
            return UtilityName;
        }

        public void Start()
        {
            Console.Clear();
            Console.WriteLine(UtilityName);
            Console.WriteLine("\n");
            DoAction();
        }

        public abstract void DoAction();
    }
}
